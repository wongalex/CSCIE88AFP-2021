package cscie88a.week3_fp;

public enum ActionResult {
	SUCCESS,
	FAILURE
}
