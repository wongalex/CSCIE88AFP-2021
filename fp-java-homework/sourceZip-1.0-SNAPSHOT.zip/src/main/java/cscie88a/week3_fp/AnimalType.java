package cscie88a.week3_fp;

public enum AnimalType {
    CAT,
    DOG,
    HEDGEHOG,
    TIGER
}
