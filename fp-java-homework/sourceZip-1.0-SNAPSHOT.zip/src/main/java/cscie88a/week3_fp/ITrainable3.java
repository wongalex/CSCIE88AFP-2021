package cscie88a.week3_fp;

/**
 * FI with multiple arguments
 */
@FunctionalInterface
public interface ITrainable3 {

    ActionResult doManyTricks(String trick1, String trick2);
}
