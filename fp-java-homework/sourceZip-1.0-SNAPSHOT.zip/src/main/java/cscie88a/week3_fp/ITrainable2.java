package cscie88a.week3_fp;

/**
 * FI with no args, with a return value
 */
@FunctionalInterface
public interface ITrainable2 {

    ActionResult doAnyTrick();
}
