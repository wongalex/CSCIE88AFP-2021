package cscie88a.week3_fp;

/**
 * FI with no arguments and no return values
 */
@FunctionalInterface
public interface ITrainable1 {

    void doAnyTrick();
}
