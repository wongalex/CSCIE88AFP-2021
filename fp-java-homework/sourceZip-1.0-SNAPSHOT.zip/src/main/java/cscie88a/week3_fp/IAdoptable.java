package cscie88a.week3_fp;

@FunctionalInterface
public interface IAdoptable {

    public boolean readyForAdoption();
}
