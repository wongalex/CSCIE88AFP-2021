package cscie88a.week3_fp;

@FunctionalInterface
public interface IAdoptable2 {

    public boolean readyForAdoption(boolean healthCheckDone);

}
