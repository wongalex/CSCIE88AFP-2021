package cscie88a.week2;

public enum ActionResult {
	SUCCESS,
	FAILURE
}
